from django.db import models

# Create your models here.
class Login(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    type = models.CharField(max_length=100)

class Portoffice(models.Model):
    beuildingno = models.CharField(max_length=100)
    beuildingname = models.CharField(max_length=100)
    licenseno = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    mobile = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pin = models.CharField(max_length=100)

class Clerk(models.Model):
    name = models.CharField(max_length=100)
    house_number = models.CharField(max_length=100)
    gender = models.CharField(max_length=100)
    joineddate = models.CharField(max_length=100)
    hname = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pin = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    PORTOFFICE = models.ForeignKey(Portoffice,on_delete=models.CASCADE)
    LOGIN = models.ForeignKey(Login, on_delete=models.CASCADE,default=1)


class Customer(models.Model):
    cname = models.CharField(max_length=100)
    pnumber = models.CharField(max_length=100)
    house = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pin = models.CharField(max_length=100)
    CLERK = models.ForeignKey(Clerk, on_delete=models.CASCADE,default="")

class Consignment(models.Model):
    CUSTOMER = models.ForeignKey(Customer, on_delete=models.CASCADE,default=1)
    destination = models.CharField(max_length=100)
    hname = models.CharField(max_length=100)
    hno = models.CharField(max_length=100)
    place = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pincode = models.CharField(max_length=100)
    parcelnarration = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    consno = models.CharField(max_length=100)
    receiver = models.CharField(max_length=100)


class Billing(models.Model):
    CONSIGNMENT = models.ForeignKey(Consignment,on_delete=models.CASCADE,default=1)
    amount = models.CharField(max_length=100)
    date = models.DateField()

class Track(models.Model):
    CONSIGNMENT = models.ForeignKey(Consignment,on_delete=models.CASCADE)
    PORTOFFICE = models.ForeignKey(Portoffice,models.CASCADE)
    CLERK=models.ForeignKey(Clerk,on_delete=models.CASCADE)
    date = models.DateField()
    time = models.CharField(max_length=100)
    status = models.CharField(max_length=100)



