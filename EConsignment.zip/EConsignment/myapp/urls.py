
from django.contrib import admin
from django.urls import path, include

from myapp import views

urlpatterns = [
    path('login/', views.login),
    path('logout/', views.Logout),
    path('loginpost/', views.loginpost),
    path('add_clerk/', views.Admin_AddClerk),
    path('add_clerk_post/', views.Addclerk_post),
    path('add_portoffice/', views.Admin_AddPortoffice),
    path('add_portoffice_post/', views.AddPortoffice_post),
    path('change_password/', views.Admin_ChangePassword),
    path('change_password_post/', views.Admin_ChangePassword_post),
    path('clerk/', views.Admin_Clerk),
    path('clerk_post/', views.Clerk_post),
    path('consignmet/', views.Admin_Consignment),
    path('consignmet_post/', views.Consignment_post_search),
    path('delivered_consignment/', views.Admin_DeliveredConsignment),
    path('delivered_consignment_post/', views.DeliveredConsignment_post),
    path('edit_clerk/<id>/', views.Admin_EditClerk),
    path('edit_clerk_post/', views.Post_Admin_EditClerk),
    path('edit_portoffice/<id>', views.Admin_EditPortoffice),
    path('edit_portoffice_post/', views.EditPortoffice_post),
    path('portoffice/',views.Admin_PortOffice),
    path('portoffice_post/',views.PortOffice_post),
    path('trackin/<id>', views.Admin_Tracking),
    path('trackin_post/', views.Tracking_post),
    path('customer/', views.Admin_Customer),
    path('customer_post/', views.Customer_post),
    path('admin_home/', views.Admin_Homepage),
    path('delete_clerk/<id>/', views.Delete_Clerk),
    path('delete_portoffice/<id>', views.Delete_Portoffice),

    path('clerk_addconsignment/', views.Clerk_AddConsignment),
    path('AddConsignment_post/', views.AddConsignment_post),
    path('clerk_addcustomer/', views.Clerk_AddCustomer),
    path('addcustomer_post/',views.AddCustomer_post),
    path('Clerk_BillReport_report/', views.Clerk_BillReport_report),
    path('clerk_billreport/', views.Clerk_BillReport),
    path('clerk_billing/<id>', views.Clerk_Billing),
    path('billreport_post/',views.BillReport_post),
    path('billing_post/',views.Billing_post),
    path('clerk_changepassword/', views.Clerk_Change_Password),
    path('clerk_change_password_post/', views.Clerk_Change_Password_post),
    path('clerk_consignment/', views.Clerk_Consignment),
    path('clerk_consignment_post/',views.Consignment_post),
    path('clerk_deliveredconsignment/', views.Clerk_DeliveredConsignment),
    path('delivered_consignment_post/', views.c_DeliveredConsignment_post),
    path('delivered_consignment_report/',views.DeliveredConsignmentReport),
    path('clerk_tracking/<id>/', views.Clerk_Tracking),
    path('clerk_viewprofile/', views.Clerk_ViewProfile),
    path('clerk_home/', views.Clerk_Homepage),
    path('clerk_updatetransit/',views.Clerk_UpdateTransit),
    path('clerk_searchconsignment/',views.SearchConsignment),
    path('clerk_updatetransit/',views.UpdateTransit),
    path('clerk_viewcustomer/',views.Clerk_ViewCustomer),
    path('clerk_viewcustomer_post/',views.ViewCustomer_post),
    path('clerk_editcustomer/<id>',views.Clerk_EditCustomer),
    path('editcustomer_post/',views.EditCustomer_post),
    path('billprint/<id>',views.Billprint)






]
