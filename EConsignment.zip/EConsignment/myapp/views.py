
from django.http import HttpResponse
from django.shortcuts import render, redirect
from myapp.models import *
# Create your views here.
def login(request):
    return render(request,'login_index.html')

def loginpost(request):
    uname=request.POST["textfield"]
    pswd=request.POST["textfield2"]
    var=Login.objects.filter(username=uname,password=pswd)
    if var.exists():
        var2=Login.objects.get(username=uname,password=pswd)
        request.session['lid']=var2.id
        if var2.type=='admin':
            return HttpResponse('''<script>alert('log in success');window.location='/myapp/admin_home/'</script>''')
        elif var2.type=='clerk':
            return HttpResponse('''<script>alert('log in success');window.location='/myapp/clerk_home/'</script>''')

        else:
            return HttpResponse('''<script>alert('invalid');window.location='/myapp/login/'</script>''')

    else:
        return HttpResponse('''<script>alert('invalid');window.location='/myapp/login/'</script>''')


def Logout(request):
    request.session['lid']=''
    return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')


def Admin_AddClerk(request):
    import datetime
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    data=Portoffice.objects.all()
    dt=datetime.date.today()
    return render(request,'Admin/Add Clerk.html',{"data":data,'dt':str(dt)})
def Addclerk_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    name=request.POST["textfield"]
    gender=request.POST["radio"]
    jdate=request.POST["textfield2"]
    hname=request.POST["textfield3"]
    hno=request.POST["number"]
    place=request.POST["textfield4"]
    city=request.POST["textfield5"]
    state=request.POST["textfield6"]
    pin=request.POST["textfield7"]
    email=request.POST["textfield8"]
    pnumber=request.POST["textfield9"]
    portoffice=request.POST["textfield10"]

    lobj=Login()
    lobj.username=email
    lobj.password=pnumber
    lobj.type="clerk"
    lobj.save()


    obj=Clerk()
    obj.name=name
    obj.gender=gender
    obj.joineddate=jdate
    obj.hname=hname
    obj.house_number=hno
    obj.place=place
    obj.city=city
    obj.state=state
    obj.pin=pin
    obj.email=email
    obj.phone=pnumber
    obj.PORTOFFICE_id=portoffice
    obj.LOGIN_id=lobj.id
    obj.save()
    return HttpResponse('''<script>alert('Clerk Added');window.location='/myapp/clerk/#tab'</script>''')

def Admin_AddPortoffice(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    return render(request,'Admin/Add Port Office.html')
def AddPortoffice_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    beuildingno=request.POST["textfield"]
    beuildingname=request.POST["textfield2"]
    licenseno=request.POST["textfield3"]
    email=request.POST["textfield4"]
    mobile=request.POST["textfield5"]
    place=request.POST["textfield6"]
    city=request.POST["textfield7"]
    state=request.POST["textfield8"]
    pin=request.POST["textfield9"]
    obj=Portoffice()
    obj.beuildingno=beuildingno
    obj.beuildingname=beuildingname
    obj.licenseno=licenseno
    obj.email=email
    obj.mobile=mobile
    obj.place=place
    obj.city=city
    obj.state=state
    obj.pin=pin
    obj.save()
    return HttpResponse('''<script>alert('Portoffice added successfully');window.location='/myapp/portoffice/#tab'</script>''')

def Admin_ChangePassword(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    return render(request,'Admin/Change Password.html')
def Admin_ChangePassword_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    oldpass=request.POST["oldpass"]
    newpass=request.POST["newpass"]
    confpass=request.POST["conpass"]
    var=Login.objects.filter(id=request.session['lid'],password=oldpass)
    if var.exists():
        if newpass==confpass:
            var3=Login.objects.filter(id=request.session['lid']).update(password=confpass)
            return HttpResponse('''<script>alert('changed');window.location='/myapp/login/'</script>''')
        else:
            return HttpResponse('''<script>alert('invalid');window.location='/myapp/login/'</script>''')
    else:
        return HttpResponse('''<script>alert('invalid');window.location='/myapp/login/'</script>''')




def Admin_Clerk(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    data=Clerk.objects.all()
    return render(request,'Admin/Clerk.html',{"data":data})
def Clerk_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    search=request.POST["textfield"]
    data=Clerk.objects.filter(name__icontains=search)
    return render(request,'Admin/Clerk.html',{"data":data})


def Admin_EditClerk(request,id):
    import datetime
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    dt = datetime.date.today()
    var=Clerk.objects.get(id=id)
    var2=Portoffice.objects.all()
    return render(request,'Admin/Edit Clerk.html',{'data':var,'data2':var2,'dt':str(dt)})
def Post_Admin_EditClerk(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    id=request.POST['id']
    name=request.POST['textfield']
    gender=request.POST['radio']
    jdate=request.POST['textfield2']
    hname=request.POST['textfield3']
    place=request.POST['textfield4']
    city=request.POST['textfield5']
    state=request.POST['textfield6']
    pin=request.POST['textfield7']
    email=request.POST['textfield8']
    pnumber=request.POST['textfield9']
    portoffice=request.POST['port']
    hno=request.POST['textfield10']


    obj = Clerk.objects.get(id=id)
    obj.name = name
    obj.gender = gender
    obj.joineddate = jdate
    obj.hname = hname
    obj.house_number = hno
    obj.place = place
    obj.city = city
    obj.state = state
    obj.pin = pin
    obj.email = email
    obj.phone = pnumber
    obj.PORTOFFICE_id =portoffice
    obj.save()
    return HttpResponse('''<script>alert('Edited');window.location='/myapp/clerk/#tab'</script>''')






def Admin_Consignment(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    var = Consignment.objects.all()
    return render(request,'Admin/Consignment.html',{'data':var})
def Consignment_post_search(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    search=request.POST['textfield']
    data = Consignment.objects.filter(CUSTOMER__cname__icontains=search)
    return render(request,'Admin/Consignment.html',{'data':data})

def Admin_DeliveredConsignment(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    delv = Consignment.objects.filter(status="Delivered")
    return render(request,'Admin/Delivered Consignment.html',{'data':delv})
def DeliveredConsignment_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    search = request.POST['textfield']
    data = Consignment.objects.filter(CUSTOMER__cname__icontains=search,status="Delivered")
    return render(request, 'Admin/Delivered Consignment.html', {'data': data})
#
# def Admin_EditClerk(request):
#     return render(request,'Admin/Edit Clerk.html')



def Admin_EditPortoffice(request,id):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    pobj=Portoffice.objects.get(id=id)
    return render(request,'Admin/Edit Portoffice.html',{'data':pobj})
def EditPortoffice_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    beuildingno=request.POST['textfield']
    beuildingname=request.POST['textfield2']
    licenseno=request.POST['textfield3']
    email=request.POST['textfield4']
    mobile=request.POST['textfield5']
    place=request.POST['textfield6']
    city=request.POST['textfield7']
    state=request.POST['textfield8']
    pin=request.POST['textfield9']
    did=request.POST['id1']
    obj=Portoffice.objects.get(id=did)
    obj.beuildingno = beuildingno
    obj.beuildingname = beuildingname
    obj.licenseno = licenseno
    obj.email = email
    obj.mobile = mobile
    obj.place = place
    obj.city = city
    obj.state = state
    obj.pin = pin
    obj.save()
    return HttpResponse('''<script>alert('Edited ');window.location='/myapp/portoffice/#tab'</script>''')

def Admin_PortOffice(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    data=Portoffice.objects.all()
    return render(request,'Admin/Port Office.html',{"data":data})
def PortOffice_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    search = request.POST["textfield"]
    data=Portoffice.objects.filter(place__icontains=search)
    return render(request,'Admin/Port Office.html',{"data":data})


def Admin_Tracking(request,id):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    data=Track.objects.filter(CONSIGNMENT__id=id)
    return render(request,'Admin/Tracking.html',{"data":data})
def Tracking_post(request):
    search = request.POST["textfield"]
    data=Track.objects.filter()

def Admin_Customer(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    var=Customer.objects.all()
    return render(request, 'Admin/Customer.html',{"data":var})
def Customer_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    search = request.POST["textfield"]
    var=Customer.objects.filter(cname__icontains=search)

    return render(request, 'Admin/Customer.html',{"data":var})

def Admin_Homepage(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    return render(request,'Admin/AdminIndex.html')
    # return render(request,'Admin/Admin Homepage.html')

def Delete_Clerk(request,id):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    # var = Clerk.objects.get(LOGIN=password)
    # var.delete()
    Login.objects.filter(id=id).update(type='rejected')
    return HttpResponse('''<script>alert('Deleted');window.location='/myapp/clerk/#tab'</script>''')

def Delete_Portoffice(request,id):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    var = Portoffice.objects.get(id=id)
    var.delete()
    return HttpResponse('''<script>alert('Deleted');window.location='/myapp/portoffice/#tab'</script>''')



def Clerk_AddConsignment(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    uu=Customer.objects.filter(CLERK__LOGIN_id=request.session['lid'])
    var=Consignment.objects.all().order_by('-id')
    cns =  0
    if var.exists():
        cns = int(var[0].consno)+1
    # print(var[0])
    return render(request,'Clerk/Add Consignment.html',{'data':uu, 'cns':str(cns)})
def AddConsignment_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    customer=request.POST['select']
    consno=request.POST['textfield14']
    receiver=request.POST['textfield11']
    hname=request.POST['textfield12']
    hno=request.POST['textfield13']
    place=request.POST['textfield4']
    city=request.POST['textfield5']
    state=request.POST['textfield6']
    pin=request.POST['textfield7']
    narration=request.POST['textfield8']
    # status=request.POST['textfield9']
    destination=request.POST['textfield15']

    obj=Consignment()
    obj.destination=destination
    obj.CUSTOMER=Customer.objects.get(id=customer)
    obj.hname=hname
    obj.hno=hno
    obj.place=place
    obj.city=city
    obj.state=state
    obj.pincode=pin
    obj.parcelnarration=narration
    obj.status='Send'
    obj.receiver=receiver
    obj.consno=consno
    obj.save()
    return HttpResponse('''<script>alert('Consignment added successfully.');window.location='/myapp/clerk_consignment/#tab'</script>''')

def Clerk_AddCustomer(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    return render(request, 'Clerk/Add Customer.html')
def AddCustomer_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    cname=request.POST['textfield']
    parcelno=request.POST['textfield2']
    house=request.POST['textfield3']
    place=request.POST['textfield4']
    city=request.POST['textfield5']
    state=request.POST['textfield6']
    pin=request.POST['textfield7']
    obj=Customer()
    obj.cname=cname
    obj.pnumber=parcelno
    obj.house=house
    obj.place=place
    obj.city=city
    obj.state=state
    obj.pin=pin
    obj.CLERK=Clerk.objects.get(LOGIN__id=request.session['lid'])
    obj.save()
    return HttpResponse('''<script>alert('Customer added');window.location='/myapp/clerk_viewcustomer/#tab'</script>''')
def Clerk_ViewCustomer(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    var=Customer.objects.filter(CLERK__LOGIN_id=request.session['lid'])
    return render(request, 'Clerk/Customer.html',{"data":var})

def ViewCustomer_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    search = request.POST["textfield"]
    var=Customer.objects.filter(cname__icontains=search,CLERK__LOGIN_id=request.session['lid'])
    return render(request, 'Clerk/Customer.html',{"data":var})

def Clerk_BillReport(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    var=Billing.objects.filter(CONSIGNMENT__CUSTOMER__CLERK__LOGIN_id=request.session['lid'])
    return render(request, 'Clerk/Bill Report.html',{'data':var})

def Clerk_BillReport_report(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    var=Billing.objects.filter(CONSIGNMENT__CUSTOMER__CLERK__LOGIN_id=request.session['lid'])
    return render(request, 'Clerk/Bill Report reports.html',{'data':var})
def BillReport_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    fromdate = request.POST['textfield']
    todate = request.POST['textfield2']
    var = Billing.objects.filter(date__range=[fromdate,todate])
    return render(request, 'Clerk/Bill Report.html', {'data': var})

def Clerk_Billing(request,id):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    return render(request, 'Clerk/Billing.html',{'id':id})



def Billing_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    id=request.POST['id']
    tax=request.POST['textfield']
    amount=request.POST['textfield2']
    obj=Billing()
    from datetime import datetime
    obj.date=datetime.now().strftime('%Y-%m-%d')
    obj.CONSIGNMENT_id=id
    obj.amount=float(amount)+(float(amount)*(float(tax)/100))
    obj.save()
    return HttpResponse("<script>alert('Success');window.location='/myapp/clerk_billing/"+id+"'</script>")

def Clerk_Change_Password(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    return render(request, 'Clerk/Change Password.html')
def Clerk_Change_Password_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    oldpass=request.POST["oldpass"]
    newpass=request.POST["newpass"]
    confpass=request.POST["conpass"]
    var=Login.objects.filter(id=request.session['lid'],password=oldpass)
    if var.exists():
        if newpass==confpass:
            var3=Login.objects.filter(id=request.session['lid']).update(password=confpass)
            return HttpResponse('''<script>alert('changed');window.location='/myapp/login/'</script>''')
        else:
            return HttpResponse('''<script>alert('invalid');window.location='/myapp/login/'</script>''')
    else:
        return HttpResponse('''<script>alert('invalid');window.location='/myapp/login/'</script>''')

def Clerk_Consignment(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    var=Consignment.objects.filter(CUSTOMER__CLERK__LOGIN_id=request.session['lid'])
    l = []
    for i in var:
        bstatus = 'pending'
        if Billing.objects.filter(CONSIGNMENT_id=i.id).exists():
            bstatus='Billed'
        l.append({'id':i.id,'consno':i.consno, 'receiver':i.receiver, 'customer':i.CUSTOMER.cname,'destination':i.destination,'housename':i.hname,'houseno':i.hno,'place':i.place,'city':i.city,'state':i.state,'pin':i.pincode,'parcelnarration':i.parcelnarration,'status':i.status,'bstatus':bstatus})
    return render(request, 'Clerk/Consignment.html',{'data':l})

def Consignment_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    search = request.POST["textfield"]
    var1=Consignment.objects.filter(CUSTOMER__CLERK__LOGIN_id=request.session['lid'],CUSTOMER__cname__icontains=search)
    l = []
    for i in var1:
        bstatus = 'pending'
        if Billing.objects.filter(CONSIGNMENT_id=i.id).exists():
            bstatus='Billed'
        l.append({'id':i.id,'consno':i.consno, 'receiver':i.receiver, 'customer':i.CUSTOMER.cname,'destination':i.destination,'housename':i.hname,'houseno':i.hno,'place':i.place,'city':i.city,'state':i.state,'pin':i.pincode,'parcelnarration':i.parcelnarration,'status':i.status,'bstatus':bstatus})
    return render(request, 'Clerk/Consignment.html',{'data':l})

def Clerk_DeliveredConsignment(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    var=Consignment.objects.filter(CUSTOMER__CLERK__LOGIN_id=request.session['lid'],status="Delivered")
    return render(request, 'Clerk/Delivered Consignment.html',{"data":var})
def c_DeliveredConsignment_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    search = request.POST['textfield']
    data = Consignment.objects.filter(CUSTOMER__cname__icontains=search,status="Delivered")
    return render(request, 'Clerk/Delivered Consignment.html', {'data': data})

def DeliveredConsignmentReport(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')
    var=Consignment.objects.filter(CUSTOMER__CLERK__LOGIN_id=request.session['lid'],status="Delivered")
    return render(request, 'Clerk/Delivered Consignment Report.html',{'data': var})


def Clerk_Tracking(request,id):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    res = Track.objects.filter(CONSIGNMENT__id=id)
    return render(request,'Clerk/Tracking.html', {"data": res})
def Tracking_post(request):
    search = request.POST["textfield"]
    data = Track.objects.filter()


def Clerk_ViewProfile(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    var=Clerk.objects.get(LOGIN_id=request.session['lid'])
    return render(request, 'Clerk/View Profile.html',{"data":var})

def Clerk_Homepage(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    return render(request, 'Clerk/ClerkIndex.html')

def Clerk_UpdateTransit(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    return render(request, 'Clerk/Update Transit.html')

def SearchConsignment(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    if request.POST["button"]=='Search':
        pnumber=request.POST["textfield2"]
        cno=request.POST["textfield"]
        print(request.POST)
        if Consignment.objects.filter(consno=cno,CUSTOMER__pnumber=pnumber).exists():
            res = Portoffice.objects.all()
            res1 = Consignment.objects.get(consno=cno,CUSTOMER__pnumber=pnumber)
            return render(request, 'Clerk/Update Transit.html', {"data": res,"data1": res1,'cons':'yes'})
        else:
            return HttpResponse('''<script>alert('No Consignment found');history.back()</script>''')
    if request.POST["button"]!='Search':
        id=request.POST["id"]
        office=request.POST["office"]
        status=request.POST["status"]
        trc=Track()
        trc.PORTOFFICE_id=office
        trc.status=status
        trc.CONSIGNMENT_id=id
        import datetime
        trc.date=datetime.date.today()
        trc.time=datetime.datetime.now().strftime('%H:%M:%S')
        trc.CLERK=Clerk.objects.get(LOGIN_id=request.session['lid'])
        trc.save()
        Consignment.objects.filter(id=id).update(status=status)
        return HttpResponse('''<script>alert('Consignment status updated');history.back()</script>''')

def UpdateTransit(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    if request.POST["button"]!='Search':
        id=request.POST["id"]
        office=request.POST["office"]
        status=request.POST["status"]
        trc=Track()
        trc.PORTOFFICE_id=office
        trc.status=status
        trc.CONSIGNMENT_id=id
        trc.CLERK=Clerk.objects.get(LOGIN_id=request.session['lid'])
        import datetime
        trc.date=datetime.date.today()
        trc.time=datetime.datetime.now().strftime('%H:%M:%S')
        trc.save()
        return HttpResponse('''<script>alert('Consignment status updated');history.back()</script>''')

def Clerk_EditCustomer(request,id):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    var=Customer.objects.get(id=id)
    return render(request, 'Clerk/Edit Customer.html',{'data':var})
def EditCustomer_post(request):
    if request.session['lid']=="":
        return HttpResponse('''<script>alert('You are logout');window.location='/myapp/login/'</script>''')

    cname=request.POST['textfield']
    parcelno=request.POST['textfield2']
    house=request.POST['textfield3']
    place=request.POST['textfield4']
    city=request.POST['textfield5']
    state=request.POST['textfield6']
    pin=request.POST['textfield7']
    id=request.POST['cid']
    obj=Customer.objects.get(id=id)
    obj.cname=cname
    obj.pnumber=parcelno
    obj.house=house
    obj.place=place
    obj.city=city
    obj.state=state
    obj.pin=pin
    obj.CLERK=Clerk.objects.get(LOGIN__id=request.session['lid'])
    obj.save()
    return HttpResponse('''<script>alert('Edited');window.location='/myapp/clerk_viewcustomer/#tab'</script>''')

def Billprint(request,id):
    var=Billing.objects.filter(CONSIGNMENT_id=id)
    print(id)
    return render(request,"Clerk/Bill Report.html",{"data":var})




